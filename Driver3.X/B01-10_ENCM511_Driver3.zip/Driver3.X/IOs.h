#ifndef IOSTUFF_H
#define	IOSTUFF_H
void IOinit(void);
void IOcheck(void);
#endif	/* IOSTUFF_H */

