#ifndef DELAY_S_H
#define	DELAY_S_H

#ifdef	__cplusplus
extern "C" {
#endif
void T2Init (void);
void delay_s (int t);
        
#ifdef	__cplusplus
}
#endif

#endif	/* DELAY_sS_H */

