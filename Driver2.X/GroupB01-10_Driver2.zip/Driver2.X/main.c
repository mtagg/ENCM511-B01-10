#include "IOs.h"
int main(void){
	IOinit();
	while(1){
		CheckPushButtons();
	} return 1;
}
