#ifndef IOSTUFF_H
#define	IOSTUFF_H
void delay_s(int t);
void IOinit(void);
void CheckPushButtons(void);
#endif	/* IOSTUFF_H */

